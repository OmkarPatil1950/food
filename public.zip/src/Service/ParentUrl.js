
const BASE_REST_API_URL='http://localhost:8080'
export default BASE_REST_API_URL;